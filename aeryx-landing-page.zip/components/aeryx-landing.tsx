'use client'

import {
  ArrowDown,
  ArrowRight,
  Check,
  Headphones,
  PackageCheck,
  ShieldCheck,
  ShoppingBag,
  Truck,
} from 'lucide-react'

const brandImage =
  'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Aeryx%20logo-05.jpg-aavJjNEt41m3jnxRsGlXIfkjD3t8ds.jpeg'
const packagingImage =
  'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-07-30%20at%206.17.23%20PM-cAL5TPCHr8fu22nQxzmplK1MdnzZ6G.jpeg'

const products = [
  { tag: 'MÁS VENDIDO', name: 'Mousepad Control Pro', category: 'Precisión', price: '$39.900', image: brandImage, position: '50% 22%' },
  { tag: 'NUEVO', name: 'Mousepad Speed XL', category: 'Velocidad', price: '$44.900', image: brandImage, position: '50% 74%' },
  { tag: 'EDICIÓN 01', name: 'Manga Performance', category: 'Rendimiento', price: '$24.900', image: packagingImage, position: '25% 50%' },
  { tag: 'PACK', name: 'Kit Competitive', category: 'Colección', price: '$69.900', image: packagingImage, position: '74% 50%' },
]

const benefits = [
  { icon: Truck, title: 'Envíos a todo el país', text: 'Seguimiento en cada etapa' },
  { icon: ShieldCheck, title: 'Compra protegida', text: 'Pagos seguros y verificados' },
  { icon: PackageCheck, title: 'Cambios simples', text: 'Hasta 30 días' },
  { icon: Headphones, title: 'Soporte real', text: 'Te ayudamos a elegir' },
]

function Mark({ className = '' }: { className?: string }) {
  return <span className={`aeryx-mark ${className}`} aria-hidden="true"><i /><b /></span>
}

function Wordmark({ compact = false }: { compact?: boolean }) {
  return <span className={compact ? 'wordmark wordmark-compact' : 'wordmark'}>aery<span className="wordmark-x">x</span></span>
}

function Header() {
  return (
    <header className="site-header">
      <a href="#inicio" className="header-brand" aria-label="Inicio de Aeryx"><Mark /><span>AERYX</span></a>
      <nav aria-label="Navegación principal">
        <a href="#productos">Productos</a><a href="#categorias">Categorías</a><a href="#marca">Nosotros</a>
      </nav>
      <a href="#productos" className="header-cta"><ShoppingBag /> Tienda <span className="cart-count">0</span></a>
    </header>
  )
}

function Hero() {
  return (
    <section id="inicio" className="hero">
      <div className="smoke smoke-one" /><div className="smoke smoke-two" /><Header />
      <div className="hero-grid" aria-hidden="true" />
      <div className="hero-copy reveal">
        <span className="eyebrow"><span>EQUIPAMIENTO GAMING PREMIUM</span><span>COLECCIÓN 01</span></span>
        <h1><span>Jugá con</span><strong>precisión.</strong></h1>
        <p>Equipamiento diseñado para transformar cada movimiento en una ventaja competitiva.</p>
        <div className="hero-actions"><a href="#productos" className="primary-button">Comprar ahora <ArrowDown /></a><a href="#categorias" className="text-link">Ver categorías <ArrowRight /></a></div>
      </div>
      <div className="hero-emblem"><Mark /></div>
      <div className="hero-bottom"><span>AERYX — BORN TO COMPETE</span><span>ENVÍOS A TODO EL PAÍS</span></div>
    </section>
  )
}

function Benefits() {
  return <section className="benefit-strip" aria-label="Beneficios de compra">{benefits.map(({ icon: Icon, title, text }) => <div className="benefit" key={title}><Icon aria-hidden="true" /><div><strong>{title}</strong><span>{text}</span></div></div>)}</section>
}

function Shop() {
  return (
    <section id="productos" className="section shop">
      <div className="section-kicker"><span>PRODUCTOS DESTACADOS</span><a href="#productos">VER TODO / 04</a></div>
      <div className="shop-heading reveal"><div><span className="mini-label">ELEGIDOS POR LA COMUNIDAD</span><h2>Prepará tu<br />mejor partida.</h2></div><p>Superficies, accesorios y equipamiento creados para jugadores que buscan control, consistencia y rendimiento.</p></div>
      <div className="product-grid">
        {products.map((product) => <article className="product-card reveal" key={product.name}>
          <div className="product-visual"><img src={product.image} style={{ objectPosition: product.position }} alt={`${product.name} de Aeryx`} /><span className="product-tag">{product.tag}</span><button aria-label={`Agregar ${product.name} al carrito`} className="quick-add"><ShoppingBag /></button></div>
          <div className="product-info"><div><span>{product.category}</span><h3>{product.name}</h3></div><strong>{product.price}</strong></div>
          <button className="add-button">Agregar al carrito <ArrowRight /></button>
        </article>)}
      </div>
    </section>
  )
}

function Categories() {
  return (
    <section id="categorias" className="section categories">
      <div className="section-kicker light"><span>COMPRÁ POR CATEGORÍA</span><span>ENCONTRÁ TU EQUIPO</span></div>
      <div className="category-grid">
        <a href="#productos" className="category-card category-large reveal"><span>01</span><div><p>CONTROL Y VELOCIDAD</p><h2>Mousepads</h2><ArrowRight /></div></a>
        <a href="#productos" className="category-card reveal"><span>02</span><div><p>RENDIMIENTO</p><h2>Accesorios</h2><ArrowRight /></div></a>
        <a href="#productos" className="category-card reveal"><span>03</span><div><p>TODO LO ESENCIAL</p><h2>Combos</h2><ArrowRight /></div></a>
      </div>
    </section>
  )
}

function Brand() {
  return (
    <section id="marca" className="brand-section">
      <div className="brand-image"><img src={brandImage} alt="Sistema de identidad visual Aeryx" /></div>
      <div className="brand-copy reveal"><span className="mini-label">NUESTRA FILOSOFÍA</span><h2>Nacimos para<br />competir.</h2><p>Diseñamos equipamiento moderno, preciso y funcional. Cada producto Aeryx combina tecnología, comodidad y una estética que no necesita exagerar.</p><ul><li><Check /> Diseño probado en juego</li><li><Check /> Materiales de alto rendimiento</li><li><Check /> Desarrollado para competir</li></ul><a href="#productos" className="primary-button">Conocer Aeryx <ArrowRight /></a></div>
    </section>
  )
}

function Newsletter() {
  return <section className="newsletter"><Mark /><div><span className="mini-label">AERYX INNER CIRCLE</span><h2>Entrá al juego.</h2><p>Recibí lanzamientos, beneficios y acceso anticipado.</p></div><form onSubmit={(event) => event.preventDefault()}><label htmlFor="email" className="sr-only">Tu correo electrónico</label><input id="email" type="email" placeholder="TU@EMAIL.COM" required /><button type="submit" aria-label="Suscribirme"><ArrowRight /></button></form></section>
}

function Footer() {
  return <footer><div className="footer-mark"><Wordmark compact /></div><div className="footer-grid"><p>EQUIPAMIENTO GAMING PREMIUM<br />PARA JUGADORES COMPETITIVOS.</p><div><span>TIENDA</span><a href="#productos">Productos</a><a href="#categorias">Categorías</a><a href="#marca">Nuestra marca</a></div><div><span>AYUDA</span><a href="mailto:hola@aeryx.gg">HOLA@AERYX.GG</a><a href="https://instagram.com/aeryx.gg" target="_blank" rel="noreferrer">@AERYX.GG</a></div></div><div className="footer-bottom"><span>© 2026 AERYX</span><span>HECHO PARA COMPETIR</span></div></footer>
}

export function AeryxLanding() {
  return <main><Hero /><Benefits /><Shop /><Categories /><Brand /><Newsletter /><Footer /></main>
}
